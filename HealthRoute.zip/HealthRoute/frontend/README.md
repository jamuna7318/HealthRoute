# HealthRoute frontend

This is the standalone React frontend for the HealthRoute API.

## Run locally

1. Start the backend with `node server.js` from `../backend`.
2. In this directory, run `npm install` once, then `npm run dev`.
3. Open the local URL printed by Vite (normally `http://localhost:5173`).

During local development, Vite proxies `/api` requests to `http://localhost:5000`. Start the backend before using search, authentication, profile, or booking features. For a deployed frontend with a separate API origin, create a `.env.local` file in this directory and set `VITE_API_URL`, for example:

```env
VITE_API_URL=http://localhost:5000
```

The app includes the home, facility search, facility details, appointment, dashboard, profile, login, and sign-up screens. The appointment screen uses the availability and booking endpoints exposed by the existing backend.

Appointments depend on the backend returning open slots. The current backend facility schema stores them under `appointment.slots`, while its appointment controller reads `appointments.slots`; the frontend reports the API response as-is and does not modify or simulate backend bookings.
