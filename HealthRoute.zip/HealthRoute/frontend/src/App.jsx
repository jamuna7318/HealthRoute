import { useEffect, useMemo, useState } from "react";
import {
  Accessibility,
  Activity,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock3,
  Compass,
  Cross,
  Heart,
  HeartPulse,
  Hospital,
  MapPin,
  Menu,
  Navigation,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Star,
  Stethoscope,
  UserRound,
  UsersRound,
  X,
} from "lucide-react";
import {
  Link,
  NavLink,
  Route,
  Routes,
  useLocation,
  useNavigate,
  useParams,
  useSearchParams,
} from "react-router-dom";

const API_URL = (import.meta.env.VITE_API_URL || "").replace(/\/$/, "");
const API_TOKEN_KEY = "healthroute-token";
const PATIENT_KEY = "healthroute-patient";

const photos = {
  hero: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=1200&q=85",
  hospital: "https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?auto=format&fit=crop&w=900&q=80",
  clinic: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=900&q=80",
  care: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=900&q=80",
  map: "https://images.unsplash.com/photo-1524666041070-9fc6a0f09c9e?auto=format&fit=crop&w=1200&q=75",
  avatar: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=180&h=180&q=80",
};

async function apiRequest(path, options = {}) {
  const token = localStorage.getItem(API_TOKEN_KEY);
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload.message || `Request failed (${response.status})`);
  }
  return payload;
}

function storedPatient() {
  try {
    return JSON.parse(localStorage.getItem(PATIENT_KEY) || "null");
  } catch {
    return null;
  }
}

const navLinks = [
  { to: "/", label: "Home", end: true },
  { to: "/facilities", label: "Find Facilities" },
  { to: "/about", label: "About" },
];

function Brand({ compact = false }) {
  return (
    <Link className={`brand${compact ? " brand-compact" : ""}`} to="/" aria-label="HealthRoute home">
      <span className="brand-mark"><HeartPulse size={20} strokeWidth={3} /></span>
      <span>HealthRoute</span>
    </Link>
  );
}

function Header({ patient, onLogout }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  useEffect(() => setMenuOpen(false), [location.pathname]);

  return (
    <header className="site-header">
      <div className="header-inner">
        <button className="icon-button mobile-menu" aria-label="Toggle navigation" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={19} /> : <Menu size={19} />}
        </button>
        <Brand />
        <nav className={`main-nav${menuOpen ? " main-nav-open" : ""}`} aria-label="Main navigation">
          {navLinks.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end} className={({ isActive }) => isActive ? "nav-link active" : "nav-link"}>
              {item.label}
            </NavLink>
          ))}
          {patient && <NavLink to="/dashboard" className={({ isActive }) => isActive ? "nav-link active" : "nav-link"}>Dashboard</NavLink>}
        </nav>
        <div className="header-actions">
          {patient ? (
            <>
              <Link className="header-user" to="/profile"><img src={photos.avatar} alt="" /><span>{patient.name?.split(" ")[0]}</span></Link>
              <button className="button button-quiet button-small" onClick={onLogout}>Log out</button>
            </>
          ) : (
            <>
              <Link className="button button-quiet button-small desktop-login" to="/login">Log in</Link>
              <Link className="button button-primary button-small" to="/signup">Sign up</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-inner">
        <Brand />
        <span>Care starts with finding the right place.</span>
        <span>© {new Date().getFullYear()} HealthRoute</span>
      </div>
    </footer>
  );
}

function App() {
  const [patient, setPatient] = useState(storedPatient);
  const navigate = useNavigate();

  function handleLogin(nextPatient, token) {
    localStorage.setItem(API_TOKEN_KEY, token);
    localStorage.setItem(PATIENT_KEY, JSON.stringify(nextPatient));
    setPatient(nextPatient);
    navigate("/dashboard");
  }

  function handleLogout() {
    localStorage.removeItem(API_TOKEN_KEY);
    localStorage.removeItem(PATIENT_KEY);
    setPatient(null);
    navigate("/");
  }

  return (
    <div className="app-shell">
      <Header patient={patient} onLogout={handleLogout} />
      <main>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/facilities" element={<SearchPage />} />
          <Route path="/facilities/:id" element={<FacilityPage />} />
          <Route path="/facilities/:id/appointment" element={<AppointmentPage patient={patient} />} />
          <Route path="/dashboard" element={<DashboardPage patient={patient} />} />
          <Route path="/profile" element={<ProfilePage patient={patient} />} />
          <Route path="/login" element={<AuthPage mode="login" onLogin={handleLogin} />} />
          <Route path="/signup" element={<AuthPage mode="signup" onLogin={handleLogin} />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

function HomePage() {
  const [query, setQuery] = useState("");
  const [city, setCity] = useState("Coimbatore");
  const navigate = useNavigate();

  function search(event) {
    event.preventDefault();
    const params = new URLSearchParams();
    if (query.trim()) params.set("service", query.trim());
    if (city.trim()) params.set("city", city.trim());
    navigate(`/facilities?${params.toString()}`);
  }

  return (
    <>
      <section className="hero-section">
        <div className="hero-copy">
          <span className="eyebrow"><span className="eyebrow-dot" /> CARE THAT FEELS CLOSER</span>
          <h1>Don’t just find a healthcare facility—<span>find a facility that fits your requirements.</span></h1>
          <p>Search and discover healthcare facilities near you, based on your needs — from services and location to accessibility and appointment availability.</p>
          <form className="hero-search" onSubmit={search}>
            <label className="search-input-wrap"><Search size={17} /><input aria-label="Search by hospital, clinic, specialty or service" placeholder="Search by hospital, clinic, specialty or service..." value={query} onChange={(event) => setQuery(event.target.value)} /></label>
            <label className="location-input-wrap"><MapPin size={16} /><input aria-label="City" value={city} onChange={(event) => setCity(event.target.value)} /></label>
            <button className="button button-primary" type="submit">Search <ArrowRight size={15} /></button>
          </form>
          <div className="hero-trust">
            <TrustItem icon={<HeartPulse />} title="Find by service" detail="Care, simplified" />
            <TrustItem icon={<MapPin />} title="Location based" detail="Near you" />
            <TrustItem icon={<ShieldCheck />} title="Trust your results" detail="Verified facilities" />
            <TrustItem icon={<Accessibility />} title="Accessibility" detail="Healthcare for all" />
          </div>
        </div>
        <div className="hero-photo-wrap">
          <img className="hero-photo" src={photos.hero} alt="Healthcare professional ready to help" />
          <div className="hero-photo-note"><span className="note-heart"><Heart size={18} fill="currentColor" /></span><span>Better healthcare<br /><strong>for a healthier tomorrow.</strong></span></div>
          <div className="hero-photo-tag"><CheckCircle2 size={16} /> Your health, your way</div>
        </div>
      </section>
      <section className="benefits-section section-wrap">
        <div className="section-heading">
          <div><span className="eyebrow">MADE FOR YOUR PEACE OF MIND</span><h2>Why choose HealthRoute?</h2></div>
          <p>Better information makes it easier to find the right care.</p>
        </div>
        <div className="benefit-grid">
          <Benefit icon={<Activity />} title="Smart Search" text="Find the right facility for your needs." tone="blue" />
          <Benefit icon={<Sparkles />} title="Real-time Availability" text="Check appointment slots instantly." tone="mint" />
          <Benefit icon={<ShieldCheck />} title="Trusted Facilities" text="Verified and reliable healthcare providers." tone="violet" />
          <Benefit icon={<Compass />} title="Easy Navigation" text="Get directions with Google Maps integration." tone="amber" />
        </div>
      </section>
      <section className="home-bottom section-wrap">
        <div><span className="eyebrow">A BETTER WAY TO FIND CARE</span><h2>The right care is closer than you think.</h2></div>
        <Link to="/facilities" className="button button-primary">Explore facilities <ArrowRight size={16} /></Link>
      </section>
    </>
  );
}

function TrustItem({ icon, title, detail }) {
  return <div className="trust-item"><span className="trust-icon">{icon}</span><span><strong>{title}</strong><small>{detail}</small></span></div>;
}

function Benefit({ icon, title, text, tone }) {
  return <article className="benefit-card"><span className={`benefit-icon ${tone}`}>{icon}</span><h3>{title}</h3><p>{text}</p></article>;
}

function useFacilities(query) {
  const [facilities, setFacilities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    const params = new URLSearchParams();
    params.set("city", query.city || "Coimbatore");
    if (query.service) params.set("service", query.service);
    if (query.type) params.set("type", query.type);
    if (query.wheelchair) params.set("wheelchairAccessible", "true");
    setLoading(true);
    setError("");
    apiRequest(`/api/facilities?${params.toString()}`)
      .then((payload) => { if (active) setFacilities(payload.data || []); })
      .catch((requestError) => { if (active) setError(requestError.message); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [query.city, query.service, query.type, query.wheelchair]);

  return { facilities, loading, error };
}

function SearchPage() {
  const [params, setParams] = useSearchParams();
  const [searchValue, setSearchValue] = useState(params.get("service") || "");
  const [cityValue, setCityValue] = useState(params.get("city") || "Coimbatore");
  const [type, setType] = useState(params.get("type") || "");
  const [wheelchair, setWheelchair] = useState(params.get("wheelchair") === "true");
  const [sort, setSort] = useState("recommended");
  const query = useMemo(() => ({
    service: params.get("service") || "",
    city: params.get("city") || "Coimbatore",
    type: params.get("type") || "",
    wheelchair: params.get("wheelchair") === "true",
  }), [params]);
  const { facilities, loading, error } = useFacilities(query);
  const sortedFacilities = useMemo(() => {
    const items = [...facilities];
    if (sort === "rating") return items.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    if (sort === "name") return items.sort((a, b) => a.name.localeCompare(b.name));
    return items;
  }, [facilities, sort]);

  function submitSearch(event) {
    event.preventDefault();
    const next = new URLSearchParams();
    if (searchValue.trim()) next.set("service", searchValue.trim());
    if (cityValue.trim()) next.set("city", cityValue.trim());
    if (type) next.set("type", type);
    if (wheelchair) next.set("wheelchair", "true");
    setParams(next);
  }

  function setQuickFilter(key, value) {
    const next = new URLSearchParams(params);
    if (next.get(key) === value) next.delete(key);
    else next.set(key, value);
    setParams(next);
    if (key === "type") setType(next.get("type") || "");
    if (key === "wheelchair") setWheelchair(next.get("wheelchair") === "true");
  }

  return (
    <div className="page-container">
      <div className="page-intro"><div><span className="eyebrow">YOUR NEXT STEP TO BETTER CARE</span><h1>Find healthcare facilities</h1><p>Search and filter to find the best facility for your needs.</p></div><span className="intro-mark"><Cross size={23} /></span></div>
      <form className="facility-search-bar" onSubmit={submitSearch}>
        <label className="input-with-icon"><Search size={16} /><input placeholder="General Medicine, Cardiology..." value={searchValue} onChange={(event) => setSearchValue(event.target.value)} /></label>
        <label className="input-with-icon location-field"><MapPin size={16} /><input aria-label="Search city" value={cityValue} onChange={(event) => setCityValue(event.target.value)} /></label>
        <button className="button button-primary search-submit" aria-label="Search facilities"><Search size={18} /></button>
      </form>
      <div className="filter-row"><div className="filter-label"><SlidersHorizontal size={15} /> Filters</div>
        <button className={`filter-chip${!type && !wheelchair ? " selected" : ""}`} onClick={() => { setType(""); setWheelchair(false); setParams({ city: query.city, ...(query.service ? { service: query.service } : {}) }); }}><SlidersHorizontal size={13} /> All filters</button>
        <button className={`filter-chip${type === "Hospital" ? " selected" : ""}`} onClick={() => setQuickFilter("type", "Hospital")}>Hospitals</button>
        <button className={`filter-chip${type === "Clinic" ? " selected" : ""}`} onClick={() => setQuickFilter("type", "Clinic")}>Clinics</button>
        <button className={`filter-chip${wheelchair ? " selected" : ""}`} onClick={() => setQuickFilter("wheelchair", "true")}><Accessibility size={14} /> Wheelchair accessible</button>
        <label className="sort-select">Sort by <select value={sort} onChange={(event) => setSort(event.target.value)} aria-label="Sort facilities"><option value="recommended">Recommended</option><option value="rating">Top rated</option><option value="name">Name</option></select><ChevronDown size={13} /></label>
      </div>
      <div className="results-heading"><div><h2>Facilities near you</h2>{!loading && !error && <span>{facilities.length} {facilities.length === 1 ? "result" : "results"} found</span>}</div><span className="results-city"><MapPin size={14} /> {query.city}</span></div>
      {loading ? <LoadingState label="Finding facilities near you..." /> : error ? <ErrorState message={error} onRetry={() => window.location.reload()} /> : facilities.length ? (
        <div className="facility-list">{sortedFacilities.map((facility, index) => <FacilityCard key={facility._id || facility.id || index} facility={facility} index={index} />)}</div>
      ) : (
        <EmptyState icon={<Hospital />} title="No facilities found" message="Try another specialty, remove a filter, or search a nearby city." action={<button className="button button-outline" onClick={() => { setSearchValue(""); setType(""); setWheelchair(false); setParams({ city: query.city }); }}>Clear search filters</button>} />
      )}
      <p className="data-note"><ShieldCheck size={14} /> Facility information is provided by healthcare providers and may change. Please confirm details before visiting.</p>
    </div>
  );
}

function FacilityCard({ facility, index = 0 }) {
  const image = [photos.hospital, photos.clinic, photos.care][index % 3];
  const services = facility.services || [];
  const open = facility.operatingHours?.is24Hours ? "Open 24 hours" : facility.operatingHours?.open && facility.operatingHours?.close ? `${formatTime(facility.operatingHours.open)} – ${formatTime(facility.operatingHours.close)}` : "Hours not listed";
  return (
    <article className="facility-card">
      <Link to={`/facilities/${facility._id || facility.id}`} className="facility-image-link" aria-label={`View ${facility.name}`}>
        <img className="facility-image" src={facility.photoUrl || facility.image || image} alt={`${facility.name} building`} loading="lazy" />
      </Link>
      <div className="facility-card-content">
        <div className="facility-name-row"><div><h3>{facility.name}</h3><span className="facility-type"><Hospital size={13} /> {facility.facilityType || "Healthcare facility"}</span></div>{facility.verified && <span className="verified-pill"><BadgeCheck size={13} /> Verified</span>}</div>
        <div className="facility-meta">
          <span><Star size={13} fill="currentColor" /> <strong>{typeof facility.rating === "number" ? facility.rating.toFixed(1) : "New"}</strong> <small>rating</small></span>
          <span><MapPin size={13} /> {facility.address || facility.city}</span>
          {services.length > 0 && <span><Stethoscope size={13} /> {services.slice(0, 2).join(", ")}{services.length > 2 ? ` +${services.length - 2} more` : ""}</span>}
        </div>
        <div className="facility-card-bottom"><span className="open-hours"><span className="status-dot" /> {open}</span><Link className="button button-primary button-small" to={`/facilities/${facility._id || facility.id}`}>View details <ArrowRight size={14} /></Link></div>
      </div>
    </article>
  );
}

function FacilityPage() {
  const { id } = useParams();
  const [facility, setFacility] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    setLoading(true);
    apiRequest(`/api/facilities/${encodeURIComponent(id)}`)
      .then((payload) => { if (active) setFacility(payload.data); })
      .catch((requestError) => { if (active) setError(requestError.message); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [id]);

  if (loading) return <div className="page-container"><LoadingState label="Loading facility details..." /></div>;
  if (error || !facility) return <div className="page-container"><ErrorState message={error || "Facility not found"} onRetry={() => window.location.reload()} backLink="/facilities" /></div>;

  const coords = facility.location;
  const mapsUrl = coords?.latitude && coords?.longitude
    ? `https://www.google.com/maps/search/?api=1&query=${coords.latitude},${coords.longitude}`
    : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${facility.name} ${facility.address || ""}`)}`;
  const hours = facility.operatingHours || {};
  return (
    <div className="page-container detail-page">
      <Link to="/facilities" className="back-link"><ArrowLeft size={15} /> Back to facilities</Link>
      <div className="detail-cover"><img src={facility.photoUrl || facility.image || photos.hospital} alt={`${facility.name}`} /><span className="cover-badge"><Hospital size={15} /> {facility.facilityType || "Healthcare facility"}</span></div>
      <div className="detail-title-row"><div><div className="detail-title-tags">{facility.verified && <span className="verified-pill"><BadgeCheck size={13} /> Verified provider</span>}</div><h1>{facility.name}</h1><p><MapPin size={15} /> {facility.address}{facility.city ? `, ${facility.city}` : ""}</p><div className="detail-facts"><span><Star size={15} fill="currentColor" /> <strong>{typeof facility.rating === "number" ? facility.rating.toFixed(1) : "New"}</strong> <span>rating</span></span><span><MapPin size={15} /> {facility.city || "Location available"}</span><span><Hospital size={15} /> {facility.facilityType || "Medical facility"}</span></div></div><Link className="button button-primary detail-book-button" to={`/facilities/${id}/appointment`}>Book appointment <ArrowRight size={16} /></Link></div>
      <div className="detail-content-grid">
        <section className="detail-main">
          <div className="detail-tabs"><a href="#overview" className="active">Overview</a><a href="#services">Facilities & services</a><a href="#location">Location</a></div>
          <section id="overview" className="detail-section"><h2>About this facility</h2><p>{facility.description || `${facility.name} is a ${String(facility.facilityType || "healthcare facility").toLowerCase()} in ${facility.city || "your area"}, providing healthcare services to the local community.`}</p></section>
          <section id="services" className="detail-section"><h2>Services available</h2><div className="service-tags">{facility.services?.length ? facility.services.map((service) => <span className="service-tag" key={service}><Check size={13} /> {service}</span>) : <span className="muted-copy">Contact the facility for service information.</span>}</div></section>
          <section id="location" className="detail-section location-section"><div className="section-title-row"><h2>Location</h2><a className="text-link" href={mapsUrl} target="_blank" rel="noreferrer">Get directions <ArrowUpRight size={14} /></a></div><div className="map-panel" style={{ backgroundImage: `linear-gradient(90deg, rgba(234,244,255,.25), rgba(234,244,255,.05)), url("${photos.map}")` }}><div className="map-location-pin"><MapPin size={22} fill="currentColor" /></div><div className="map-label"><MapPin size={14} /> {facility.address || facility.city}</div><a className="button button-primary button-small" href={mapsUrl} target="_blank" rel="noreferrer"><Navigation size={14} /> Open map</a></div></section>
        </section>
        <aside className="detail-sidebar"><h2>Good to know</h2><InfoRow icon={<Clock3 />} title="Operating hours" detail={hours.is24Hours ? "Open 24 hours" : `${formatTime(hours.open)} – ${formatTime(hours.close)}`} /><InfoRow icon={<CalendarDays />} title="Appointments" detail={facility.appointment?.bookingAvailable ? "Booking available" : "Contact facility to book"} /><InfoRow icon={<Accessibility />} title="Accessibility" detail={facility.accessibility?.wheelchairAccessible ? "Wheelchair friendly" : "Contact facility for details"} /><InfoRow icon={<ShieldCheck />} title="Provider status" detail={facility.verified ? "Verified on HealthRoute" : "Listed on HealthRoute"} /></aside>
      </div>
    </div>
  );
}

function InfoRow({ icon, title, detail }) {
  return <div className="info-row"><span className="info-icon">{icon}</span><span><strong>{title}</strong><small>{detail}</small></span></div>;
}

function AppointmentPage({ patient }) {
  const { id } = useParams();
  const [facility, setFacility] = useState(null);
  const [slots, setSlots] = useState([]);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedSlot, setSelectedSlot] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError("");
    Promise.all([
      apiRequest(`/api/facilities/${encodeURIComponent(id)}`),
      apiRequest(`/api/appointments/${encodeURIComponent(id)}/slots`),
    ]).then(([facilityPayload, slotsPayload]) => {
      if (!active) return;
      setFacility(facilityPayload.data);
      setSlots(slotsPayload.data || []);
    }).catch((requestError) => {
      if (active) setError(requestError.message);
    }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [id]);

  const availableDates = [...new Set(slots.filter((slot) => slot.available).map((slot) => normalizeDate(slot.date)))];
  const slotsForDate = slots.filter((slot) => slot.available && normalizeDate(slot.date) === selectedDate);

  async function bookAppointment(event) {
    event.preventDefault();
    if (!patient) {
      navigate(`/login?next=${encodeURIComponent(`/facilities/${id}/appointment`)}`);
      return;
    }
    const slot = slotsForDate.find((item) => item.time === selectedSlot);
    if (!slot) {
      setNotice("Choose an available date and time to continue.");
      return;
    }
    setSubmitting(true);
    setNotice("");
    try {
      const result = await apiRequest(`/api/appointments/${encodeURIComponent(id)}/book`, {
        method: "POST",
        body: JSON.stringify({ date: selectedDate, time: selectedSlot }),
      });
      const bookings = getBookedAppointments();
      bookings.unshift({ facilityId: id, facility: facility.name, date: selectedDate, time: selectedSlot });
      localStorage.setItem("healthroute-booked-appointments", JSON.stringify(bookings));
      setNotice(result.message || "Your appointment slot was reserved.");
      setSlots((existing) => existing.filter((item) => !(normalizeDate(item.date) === selectedDate && item.time === selectedSlot)));
      setSelectedSlot("");
    } catch (requestError) {
      setNotice(requestError.message);
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) return <div className="page-container"><LoadingState label="Checking available appointments..." /></div>;
  if (error || !facility) return <div className="page-container"><ErrorState message={error || "Facility not found"} backLink={`/facilities/${id}`} /></div>;

  return (
    <div className="page-container appointment-page">
      <Link to={`/facilities/${id}`} className="back-link"><ArrowLeft size={15} /> Back to facility</Link>
      <div className="page-intro"><div><span className="eyebrow">PLAN YOUR VISIT</span><h1>Book an appointment</h1><p>Choose an available date and time at {facility.name}.</p></div><span className="intro-mark"><CalendarDays size={22} /></span></div>
      <form className="booking-layout" onSubmit={bookAppointment}>
        <section className="booking-card"><h2><CalendarDays size={18} /> Choose a date</h2><p className="muted-copy">Available dates provided by the facility</p>
          {availableDates.length ? <div className="date-list">{availableDates.map((date) => <button type="button" className={`date-option${selectedDate === date ? " selected" : ""}`} key={date} onClick={() => { setSelectedDate(date); setSelectedSlot(""); }}>{formatDate(date)}<ArrowRight size={15} /></button>)}</div> : <div className="no-slots"><CalendarDays size={24} /><strong>No available dates yet</strong><span>This facility has not published appointment slots. Please contact them directly to schedule your visit.</span></div>}
        </section>
        <section className="booking-card"><h2><Clock3 size={18} /> Available times</h2><p className="muted-copy">{selectedDate ? formatDate(selectedDate) : "Select a date to see available times"}</p>
          {slotsForDate.length ? <div className="time-grid">{slotsForDate.map((slot) => <button type="button" key={`${slot.date}-${slot.time}`} className={`time-option${selectedSlot === slot.time ? " selected" : ""}`} onClick={() => setSelectedSlot(slot.time)}>{formatTime(slot.time)}</button>)}</div> : <div className="slot-placeholder"><Clock3 size={20} /><span>{selectedDate ? "No open times on this date." : "Your available times will appear here."}</span></div>}
          {notice && <div className={`inline-notice${notice.toLowerCase().includes("reserved") ? " notice-success" : ""}`} role="status">{notice}</div>}
          <div className="booking-summary"><div><span>Facility</span><strong>{facility.name}</strong></div><div><span>Date & time</span><strong>{selectedSlot && selectedDate ? `${formatDate(selectedDate)} · ${formatTime(selectedSlot)}` : "Not selected"}</strong></div></div>
          <button className="button button-primary button-full" type="submit" disabled={submitting || !slotsForDate.length}>{submitting ? "Booking..." : patient ? "Confirm appointment" : "Log in to continue"} <ArrowRight size={16} /></button>
          {!patient && <p className="form-footnote">You’ll need a HealthRoute account to book.</p>}
        </section>
      </form>
    </div>
  );
}

function DashboardPage({ patient }) {
  const [error, setError] = useState("");
  const [profile, setProfile] = useState(patient);
  const [profileLoading, setProfileLoading] = useState(Boolean(patient));
  const query = { city: "Coimbatore" };
  const { facilities, loading, error: facilityError } = useFacilities(query);
  const appointments = getBookedAppointments();
  const navigate = useNavigate();
  useEffect(() => {
    if (!patient) return;
    apiRequest("/api/patients/profile").then((payload) => setProfile(payload.patient)).catch((requestError) => setError(requestError.message)).finally(() => setProfileLoading(false));
  }, [patient]);

  if (!patient) return <SignInPrompt title="Your dashboard is waiting" message="Log in to see your profile and continue your healthcare journey." />;

  return (
    <div className="page-container dashboard-page">
      <div className="dashboard-greeting"><div><span className="eyebrow">YOUR HEALTH, ALL IN ONE PLACE</span><h1>Hello, {profile?.name?.split(" ")[0] || patient.name?.split(" ")[0]} <span className="wave">✦</span></h1><p>Here’s a little snapshot of your HealthRoute.</p></div><div className="dashboard-greeting-icon"><HeartPulse size={26} /></div></div>
      {error && <div className="inline-notice" role="alert">{error}</div>}
      <section className="welcome-card"><div className="welcome-icon"><CalendarDays size={22} /></div><div><span className="welcome-kicker">YOUR HEALTH JOURNEY</span><h2>{appointments.length ? "Your upcoming appointment" : "Ready to find your care?"}</h2><p>{appointments.length ? appointments[0].facility : "Explore nearby facilities and find care that fits your needs."}</p></div><Link to={appointments.length ? `/facilities/${appointments[0].facilityId}` : "/facilities"} className="button button-white">{appointments.length ? "View facility" : "Find facilities"} <ArrowRight size={15} /></Link></section>
      <div className="dashboard-grid">
        <Link className="dashboard-tile" to="/facilities"><span className="dashboard-tile-icon blue"><Search size={19} /></span><strong>Find Facilities</strong><span>Search nearby hospitals and clinics.</span><ArrowRight className="tile-arrow" size={15} /></Link>
        <Link className="dashboard-tile" to="/profile"><span className="dashboard-tile-icon mint"><UserRound size={19} /></span><strong>My Profile</strong><span>View your account information.</span><ArrowRight className="tile-arrow" size={15} /></Link>
        <Link className="dashboard-tile" to="/facilities"><span className="dashboard-tile-icon violet"><CalendarDays size={19} /></span><strong>Appointments</strong><span>{appointments.length ? `${appointments.length} appointment${appointments.length > 1 ? "s" : ""} saved on this device.` : "Appointments you've booked on this device."}</span><ArrowRight className="tile-arrow" size={15} /></Link>
      </div>
      <section className="dashboard-nearby"><div className="section-title-row"><div><span className="eyebrow">START EXPLORING</span><h2>Facilities near you</h2></div><Link to="/facilities" className="text-link">See all <ArrowRight size={15} /></Link></div>
        {loading ? <LoadingState label="Finding nearby facilities..." /> : facilityError ? <ErrorState message={facilityError} onRetry={() => window.location.reload()} /> : facilities.length ? <div className="mini-facility-list">{facilities.slice(0, 2).map((facility, index) => <FacilityCard key={facility._id} facility={facility} index={index} />)}</div> : <p className="muted-copy">No facilities have been listed for your area yet.</p>}
      </section>
      {profileLoading && <span className="muted-copy">Refreshing your account…</span>}
    </div>
  );
}

function ProfilePage({ patient }) {
  const [profile, setProfile] = useState(patient);
  const [loading, setLoading] = useState(Boolean(patient));
  const [error, setError] = useState("");
  useEffect(() => {
    if (!patient) return;
    apiRequest("/api/patients/profile").then((payload) => setProfile(payload.patient)).catch((requestError) => setError(requestError.message)).finally(() => setLoading(false));
  }, [patient]);

  if (!patient) return <SignInPrompt title="Sign in to view your profile" message="Your profile information is private to your HealthRoute account." />;
  return (
    <div className="page-container profile-page">
      <div className="page-intro"><div><span className="eyebrow">YOUR ACCOUNT</span><h1>My profile</h1><p>Your HealthRoute account information.</p></div><span className="intro-mark"><UserRound size={22} /></span></div>
      {error && <div className="inline-notice" role="alert">{error}</div>}
      <section className="profile-card"><div className="profile-person"><img src={photos.avatar} alt="" /><div><h2>{profile?.name || patient.name}</h2><span className="verified-pill"><CheckCircle2 size={13} /> HealthRoute member</span></div></div><div className="profile-info-list"><InfoRow icon={<UserRound />} title="Full name" detail={profile?.name || patient.name || "Not provided"} /><InfoRow icon={<span className="at-icon">@</span>} title="Email address" detail={profile?.email || patient.email || "Not provided"} /><InfoRow icon={<UsersRound />} title="Phone number" detail={profile?.phone || patient.phone || "Not provided"} /></div>{loading && <p className="muted-copy">Loading your latest profile…</p>}</section>
      <section className="profile-note"><ShieldCheck size={17} /><p>Your personal details are only used to provide HealthRoute services. To update your account information, please contact support.</p></section>
    </div>
  );
}

function getBookedAppointments() {
  try {
    return JSON.parse(localStorage.getItem("healthroute-booked-appointments") || "[]");
  } catch {
    return [];
  }
}

function SignInPrompt({ title, message }) {
  return <div className="auth-page"><div className="auth-card prompt-card"><div className="auth-brand"><Brand /></div><span className="auth-emblem"><HeartPulse size={24} /></span><h1>{title}</h1><p>{message}</p><Link className="button button-primary button-full" to="/login">Log in <ArrowRight size={15} /></Link><p className="auth-switch">New to HealthRoute? <Link to="/signup">Create an account</Link></p></div></div>;
}

function AuthPage({ mode, onLogin }) {
  const isSignup = mode === "signup";
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  function update(event) {
    setForm({ ...form, [event.target.name]: event.target.value });
  }

  async function submit(event) {
    event.preventDefault();
    setLoading(true);
    setError("");
    try {
      if (isSignup) {
        const result = await apiRequest("/api/auth/register", { method: "POST", body: JSON.stringify(form) });
        navigate("/login", { state: { registeredEmail: result.patient?.email || form.email } });
      } else {
        const result = await apiRequest("/api/auth/login", { method: "POST", body: JSON.stringify({ email: form.email, password: form.password }) });
        onLogin(result.patient, result.token);
        const next = searchParams.get("next");
        if (next?.startsWith("/facilities/") && !next.includes("\\")) navigate(next);
      }
    } catch (requestError) {
      setError(requestError.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-brand"><Brand /></div>
        <div className="auth-emblem"><HeartPulse size={25} /></div>
        <span className="eyebrow">{isSignup ? "YOUR HEALTH JOURNEY STARTS HERE" : "WELCOME BACK"}</span>
        <h1>{isSignup ? "Create your account" : "Welcome back!"}</h1>
        <p className="auth-description">{isSignup ? "Join HealthRoute and find healthcare that works for you." : "Log in to your HealthRoute account."}</p>
        <form className="auth-form" onSubmit={submit}>
          {isSignup && <label>Full name<input name="name" autoComplete="name" placeholder="Enter your full name" value={form.name} onChange={update} required /></label>}
          <label>Email address<input name="email" type="email" autoComplete="email" placeholder="Enter your email" value={form.email} onChange={update} required /></label>
          {isSignup && <label>Phone number <span className="optional-label">Optional</span><input name="phone" type="tel" autoComplete="tel" placeholder="Enter your phone number" value={form.phone} onChange={update} /></label>}
          <label>Password<input name="password" type="password" autoComplete={isSignup ? "new-password" : "current-password"} placeholder={isSignup ? "At least 8 characters" : "Enter your password"} minLength={isSignup ? 8 : undefined} value={form.password} onChange={update} required /></label>
          {!isSignup && <div className="forgot-row"><span>Secure sign-in</span><ShieldCheck size={14} /></div>}
          {error && <div className="inline-notice" role="alert">{error}</div>}
          <button className="button button-primary button-full" type="submit" disabled={loading}>{loading ? (isSignup ? "Creating account..." : "Logging in...") : (isSignup ? "Create account" : "Log in")} <ArrowRight size={16} /></button>
        </form>
        <div className="auth-or"><span>OR</span></div>
        <p className="auth-switch">{isSignup ? "Already have an account?" : "Don’t have an account?"} <Link to={isSignup ? "/login" : "/signup"}>{isSignup ? "Log in" : "Sign up"}</Link></p>
        <p className="auth-legal">By continuing, you agree to use HealthRoute responsibly. Your account details are handled securely.</p>
      </div>
    </div>
  );
}

function AboutPage() {
  return <div className="page-container about-page"><span className="eyebrow">ABOUT HEALTHROUTE</span><h1>Finding care should feel simple.</h1><p className="about-lede">HealthRoute helps people discover healthcare facilities that fit their needs, in the places they live.</p><div className="about-grid"><Benefit icon={<Search />} title="Find the right care" text="Search facilities by specialty, location and accessibility." tone="blue" /><Benefit icon={<ShieldCheck />} title="Make informed choices" text="See useful details about services, hours and providers." tone="mint" /><Benefit icon={<HeartPulse />} title="Feel supported" text="A clearer path from finding a facility to planning a visit." tone="violet" /></div><Link to="/facilities" className="button button-primary">Find a facility <ArrowRight size={15} /></Link></div>;
}

function NotFoundPage() {
  return <div className="page-container not-found"><span className="eyebrow">PAGE NOT FOUND</span><h1>Looks like this path ends here.</h1><p>Let’s find a better route to the care you need.</p><Link className="button button-primary" to="/">Go to home <ArrowRight size={15} /></Link></div>;
}

function EmptyState({ icon, title, message, action }) {
  return <div className="empty-state"><span className="empty-icon">{icon}</span><h2>{title}</h2><p>{message}</p>{action}</div>;
}

function LoadingState({ label }) {
  return <div className="loading-state"><span className="spinner" />{label}</div>;
}

function ErrorState({ message, onRetry, backLink }) {
  return <EmptyState icon={<Activity />} title="We couldn’t load this right now" message={message || "Please check your connection and try again."} action={<div className="error-actions">{backLink && <Link className="button button-outline" to={backLink}>Go back</Link>}{onRetry && <button className="button button-primary" onClick={onRetry}>Try again <ArrowRight size={15} /></button>}</div>} />;
}

function formatTime(time) {
  if (!time) return "Hours not listed";
  const [hours, minutes] = String(time).split(":").map(Number);
  if (Number.isNaN(hours)) return time;
  const suffix = hours >= 12 ? "PM" : "AM";
  const normalized = hours % 12 || 12;
  return `${normalized}:${String(minutes || 0).padStart(2, "0")} ${suffix}`;
}

function normalizeDate(date) {
  if (!date) return "";
  const parsed = new Date(date);
  return Number.isNaN(parsed.getTime()) ? String(date).slice(0, 10) : parsed.toISOString().slice(0, 10);
}

function formatDate(date) {
  const parsed = new Date(`${normalizeDate(date)}T12:00:00`);
  return Number.isNaN(parsed.getTime()) ? date : new Intl.DateTimeFormat("en", { weekday: "short", month: "short", day: "numeric" }).format(parsed);
}

export default App;
