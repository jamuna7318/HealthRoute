
const { searchGooglePlaces } = require("../services/googlePlacesService");

const searchFacilities = async (req, res) => {
  try {
    const {
      query,
      city = "Coimbatore"
    } = req.query;

    if (!query || !query.trim()) {
      return res.status(400).json({
        success: false,
        message: "Search query is required"
      });
    }

    const facilities = await searchGooglePlaces(
      query.trim(),
      city.trim()
    );

    return res.status(200).json({
      success: true,
      count: facilities.length,
      search: {
        query: query.trim(),
        city: city.trim()
      },
      data: facilities
    });
  } catch (error) {
    console.error("Healthcare search failed:", error.message);

    return res.status(502).json({
      success: false,
      message: "Healthcare search failed. Check API configuration and try again."
    });
  }
};

module.exports = { searchFacilities };
