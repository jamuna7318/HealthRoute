
const Facility = require("../models/Facility");

const createFacility = async (req, res) => {
  try {
    const facility = await Facility.create(req.body);

    res.status(201).json({
      success: true,
      data: facility
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
};

const getFacilities = async (req, res) => {
  try {
    const {
      city = "Coimbatore",
      service,
      type,
      wheelchairAccessible
    } = req.query;

    const filter = {
      city: new RegExp(`^${city}$`, "i")
    };

    if (service) {
      filter.services = {
        $regex: service,
        $options: "i"
      };
    }

    if (type) {
      filter.facilityType = type;
    }

    if (wheelchairAccessible === "true") {
      filter["accessibility.wheelchairAccessible"] = true;
    }

    const facilities = await Facility.find(filter).lean();

    const rankedFacilities = facilities
      .map((facility) => {
        let score = 0;

        if (service) {
          const matched = facility.services?.some((item) =>
            item.toLowerCase().includes(service.toLowerCase())
          );

          if (matched) score += 50;
        }

        if (type && facility.facilityType === type) {
          score += 20;
        }

        if (wheelchairAccessible === "true" &&
            facility.accessibility?.wheelchairAccessible) {
          score += 30;
        }

        if (facility.verified) score += 5;

        return {
          ...facility,
          matchScore: score
        };
      })
      .sort((a, b) => b.matchScore - a.matchScore);

    res.status(200).json({
      success: true,
      count: rankedFacilities.length,
      data: rankedFacilities
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};

const getFacilityById = async (req, res) => {
  try {
    const facility = await Facility.findById(req.params.id);

    if (!facility) {
      return res.status(404).json({
        success: false,
        message: "Facility not found"
      });
    }

    res.status(200).json({
      success: true,
      data: facility
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Invalid facility ID"
    });
  }
};

module.exports = {
  createFacility,
  getFacilities,
  getFacilityById
};
