
const Facility = require("../models/Facility");

const getAvailableSlots = async (req, res) => {
  try {
    const facility = await Facility.findById(req.params.facilityId);

    if (!facility) {
      return res.status(404).json({
        success: false,
        message: "Facility not found"
      });
    }

    const slots = facility.appointments?.slots || [];
    const availableSlots = slots.filter(
      (slot) => slot.available === true
    );

    res.status(200).json({
      success: true,
      facility: facility.name,
      count: availableSlots.length,
      data: availableSlots
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Unable to retrieve appointment slots"
    });
  }
};

const bookAppointment = async (req, res) => {
  try {
    const { date, time } = req.body;

    if (!date || !time) {
      return res.status(400).json({
        success: false,
        message: "Date and time are required"
      });
    }

    const facility = await Facility.findOneAndUpdate(
      {
        _id: req.params.facilityId,
        "appointments.slots": {
          $elemMatch: {
            date,
            time,
            available: true
          }
        }
      },
      {
        $set: {
          "appointments.slots.$.available": false
        }
      },
      { new: true }
    );

    if (!facility) {
      return res.status(409).json({
        success: false,
        message: "Slot unavailable or facility not found"
      });
    }

    res.status(200).json({
      success: true,
      message: "Slot reserved in HealthRoute",
      facility: facility.name,
      date,
      time
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Unable to reserve appointment slot"
    });
  }
};

module.exports = {
  getAvailableSlots,
  bookAppointment
};
