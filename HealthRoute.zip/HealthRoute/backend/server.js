
const express = require("express");
const cors = require("cors");
require("dotenv").config();

const connectDB = require("./config/db");

const facilityRoutes = require("./routes/facilityRoutes");
const googlePlacesRoutes = require("./routes/googlePlacesRoutes");
const appointmentRoutes = require("./routes/appointmentRoutes");
const authRoutes = require("./routes/authRoutes");
const patientRoutes = require("./routes/patientRoutes");

const app = express();

// Check route imports
console.log("Route check:", {
  facilityRoutes: typeof facilityRoutes,
  googlePlacesRoutes: typeof googlePlacesRoutes,
  appointmentRoutes: typeof appointmentRoutes,
  authRoutes: typeof authRoutes,
});

// Middleware
app.use(cors());
app.use(express.json());

// Home route
app.get("/", (req, res) => {
  res.status(200).json({
    success: true,
    message: "Welcome to HealthRoute API",
  });
});

// Health check route
app.get("/api/health", (req, res) => {
  res.status(200).json({
    success: true,
    message: "HealthRoute backend is running",
  });
});

// API routes
app.use("/api/facilities", facilityRoutes);
app.use("/api/google-places", googlePlacesRoutes);
app.use("/api/appointments", appointmentRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/patients", patientRoutes);

// Handle unknown routes
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "API route not found",
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error("API Error:", err.message);

  res.status(err.status || 500).json({
    success: false,
    message: err.status ? err.message : "Internal server error",
  });
});

// Start server
const PORT = process.env.PORT || 5000;

const startServer = async () => {
  try {
    await connectDB();

    app.listen(PORT, () => {
      console.log(`HealthRoute server running on port ${PORT}`);
    });
  } catch (error) {
    console.error("Failed to start HealthRoute:", error.message);
    process.exit(1);
  }
};

startServer();
