
const searchGooglePlaces = async (query, city = "Coimbatore") => {
  if (!process.env.GOOGLE_PLACES_API_KEY) {
    throw new Error("Google Places API key is missing");
  }

  const response = await fetch(
    "https://places.googleapis.com/v1/places:searchText",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": process.env.GOOGLE_PLACES_API_KEY,
        "X-Goog-FieldMask":
          "places.id,places.displayName,places.formattedAddress,places.location,places.primaryType,places.nationalPhoneNumber,places.googleMapsUri"
      },
      body: JSON.stringify({
        textQuery: `${query} in ${city}, Tamil Nadu, India`,
        regionCode: "IN",
        languageCode: "en",
        maxResultCount: 10
      })
    }
  );

  const data = await response.json();

  if (!response.ok) {
    throw new Error(
      data.error?.message || "Google Places search failed"
    );
  }

  return (data.places || []).map((place) => ({
    placeId: place.id,
    name: place.displayName?.text || "Unknown facility",
    address: place.formattedAddress || "",
    location: place.location || null,
    type: place.primaryType || "healthcare",
    phone: place.nationalPhoneNumber || "",
    googleMapsUrl: place.googleMapsUri || ""
  }));
};

module.exports = { searchGooglePlaces };
