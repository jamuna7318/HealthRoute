
const express = require("express");
const router = express.Router();

const {
  getAvailableSlots,
  bookAppointment
} = require("../controllers/appointmentController");

router.get("/:facilityId/slots", getAvailableSlots);
router.post("/:facilityId/book", bookAppointment);

module.exports = router;
