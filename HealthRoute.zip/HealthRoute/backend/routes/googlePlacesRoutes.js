
const express = require("express");
const router = express.Router();

const {
  searchFacilities
} = require("../controllers/googlePlacesController");

router.get("/search", searchFacilities);

module.exports = router;
