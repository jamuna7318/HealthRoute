
const express = require("express");
const router = express.Router();

const { getPatientProfile } = require("../controllers/patientController");
const authMiddleware = require("../middleware/authMiddleware");

router.get("/profile", authMiddleware, getPatientProfile);

module.exports = router;
