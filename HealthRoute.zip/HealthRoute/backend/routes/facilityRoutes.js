
const express = require("express");
const router = express.Router();

const {
  createFacility,
  getFacilities,
  getFacilityById,
} = require("../controllers/facilityController");

const authMiddleware = require("../middleware/authMiddleware");

// View facilities publicly
router.get("/", getFacilities);
router.get("/:id", getFacilityById);

// Require login to create a facility
router.post("/", authMiddleware, createFacility);

module.exports = router;
