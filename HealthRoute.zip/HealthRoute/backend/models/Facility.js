
const mongoose = require("mongoose");

const facilitySchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    facilityType: {
      type: String,
      enum: ["Hospital", "Clinic", "Diagnostic Center", "Pharmacy", "Other"],
      required: true,
    },
    city: {
      type: String,
      required: true,
      default: "Coimbatore",
      trim: true,
      index: true,
    },
    address: {
      type: String,
      required: true,
      trim: true,
    },
    location: {
      latitude: {
        type: Number,
        required: true,
        min: -90,
        max: 90,
      },
      longitude: {
        type: Number,
        required: true,
        min: -180,
        max: 180,
      },
    },
    services: [{
      type: String,
      trim: true,
    }],
    operatingHours: {
      open: {
        type: String,
        default: "09:00",
      },
      close: {
        type: String,
        default: "18:00",
      },
      days: [{
        type: String,
      }],
      is24Hours: {
        type: Boolean,
        default: false,
      },
    },
    accessibility: {
      wheelchairAccessible: {
        type: Boolean,
        default: false,
      },
      accessibleRestroom: {
        type: Boolean,
        default: false,
      },
      parkingAvailable: {
        type: Boolean,
        default: false,
      },
    },
    appointment: {
      bookingAvailable: {
        type: Boolean,
        default: false,
      },
      slots: [{
        date: Date,
        time: String,
        available: {
          type: Boolean,
          default: true,
        },
      }],
    },
    phone: {
      type: String,
      trim: true,
    },
    rating: {
      type: Number,
      min: 0,
      max: 5,
    },
    verified: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

facilitySchema.index({
  name: "text",
  address: "text",
  services: "text",
});

module.exports = mongoose.model("Facility", facilitySchema);
