
require("dotenv").config();
const mongoose = require("mongoose");
const Facility = require("../models/Facility");

const facilities = [
  {
    name: "HealthRoute Sample Multispeciality Hospital",
    facilityType: "Hospital",
    city: "Coimbatore",
    address: "Gandhipuram, Coimbatore, Tamil Nadu",
    location: { latitude: 11.0183, longitude: 76.9674 },
    services: ["General Medicine", "Cardiology", "Orthopedics"],
    operatingHours: {
      open: "00:00",
      close: "23:59",
      days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
      is24Hours: true
    },
    accessibility: {
      wheelchairAccessible: true,
      accessibleRestroom: true,
      parkingAvailable: true
    },
    appointment: { bookingAvailable: true, slots: [] },
    phone: "SAMPLE-NOT-REAL",
    verified: false
  },
  {
    name: "HealthRoute Sample Diagnostic Center",
    facilityType: "Diagnostic Center",
    city: "Coimbatore",
    address: "Peelamedu, Coimbatore, Tamil Nadu",
    location: { latitude: 11.0281, longitude: 77.0122 },
    services: ["Blood Test", "X-Ray", "Ultrasound"],
    operatingHours: {
      open: "08:00",
      close: "18:00",
      days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
      is24Hours: false
    },
    accessibility: {
      wheelchairAccessible: true,
      accessibleRestroom: false,
      parkingAvailable: true
    },
    appointment: { bookingAvailable: true, slots: [] },
    phone: "SAMPLE-NOT-REAL",
    verified: false
  },
  {
    name: "HealthRoute Sample Orthopedic Clinic",
    facilityType: "Clinic",
    city: "Coimbatore",
    address: "RS Puram, Coimbatore, Tamil Nadu",
    location: { latitude: 11.0068, longitude: 76.9475 },
    services: ["Orthopedics", "Physiotherapy", "Joint Consultation"],
    operatingHours: {
      open: "09:00",
      close: "17:00",
      days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
      is24Hours: false
    },
    accessibility: {
      wheelchairAccessible: false,
      accessibleRestroom: false,
      parkingAvailable: true
    },
    appointment: { bookingAvailable: false, slots: [] },
    phone: "SAMPLE-NOT-REAL",
    verified: false
  }
];

const seedFacilities = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);

    await Facility.deleteMany({
      name: { $regex: "^HealthRoute Sample" }
    });

    await Facility.insertMany(facilities);

    console.log("Coimbatore sample facilities inserted successfully");

  } catch (error) {
    console.error("Seeding failed:", error.message);
  } finally {
    await mongoose.disconnect();
  }
};

seedFacilities();
